CanvasLayers
============

CanvasLayers is a small javascript library for adding layers to the HTML5
canvas tag.  Unlike other canvas layer libraries, which use a stack of
several canvas tags, only one canvas is used.
  

Requirements
------------

Any modern web browser (anything Webkit or Gecko-based, Opera, etc).  It even
works in IE9, but is very slow in that browser.


Links
-----

 * [BitBucket Page][1]
 * [Development Blog][2]


The Author
----------

Written by Antony Dzeryn.  For more info, email me at <ant@simianzombie.com>.
  

  [1]: http://bitbucket.org/ant512/canvaslayers
  [2]: http://simianzombie.com
